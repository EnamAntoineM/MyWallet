#pragma once

#include <cstddef>

namespace eraser
{
    template <typename T>
    std::size_t id_of();
}

#include "id.inl"
