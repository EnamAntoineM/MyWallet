#pragma once

#include "serializers/glaze/glaze.hpp"

namespace saucer
{
    using default_serializer = serializers::glaze::serializer;
}
